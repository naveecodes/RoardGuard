let roadguardMap = null;
let markers = [];
let infoWindow = null;
function sizeColor(size) { return size === 'Large' ? '#e35d5b' : size === 'Medium' ? '#e6a23c' : '#28a879'; }
function statusAllowed(report) { const filter = document.getElementById('mapFilter')?.value || 'All'; return filter === 'All' || report.status === filter; }
function mapHtml(r) { const mapLink = `https://www.google.com/maps?q=${r.latitude},${r.longitude}`; return `<div style="font-family:Arial,sans-serif;max-width:230px;color:#172b3a"><b>${escapeHtml(r.title)}</b><p style="margin:6px 0">${escapeHtml(r.road_name || 'Road name not provided')}</p><p style="margin:6px 0">Size: <b>${escapeHtml(r.size)}</b> · ${escapeHtml(r.status)}</p><a href="${mapLink}" target="_blank">Open Google Maps ↗</a></div>`; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function initRoadGuardMap() {
  const reports = window.ROADGUARD_REPORTS || [];
  const mapEl = document.getElementById('map');
  if (!window.google || !google.maps || !mapEl) return;
  mapEl.innerHTML = '';
  roadguardMap = new google.maps.Map(mapEl, {center: {lat: 30.3753, lng: 76.7821}, zoom: 13, mapTypeControl: false, streetViewControl: false, fullscreenControl: true, styles:[{featureType:'poi',stylers:[{visibility:'off'}]}]});
  infoWindow = new google.maps.InfoWindow();
  renderMarkers(reports);
}
function renderMarkers(reports) {
  markers.forEach(m => m.setMap(null)); markers = [];
  if (!roadguardMap) return;
  reports.filter(statusAllowed).forEach(r => {
    const marker = new google.maps.Marker({map:roadguardMap,position:{lat:Number(r.latitude),lng:Number(r.longitude)},title:r.title, icon:{path:google.maps.SymbolPath.CIRCLE,scale:r.size==='Large'?9:r.size==='Medium'?7:6,fillColor:sizeColor(r.size),fillOpacity:1,strokeColor:'#fff',strokeWeight:2}});
    marker.addListener('click',()=>{infoWindow.setContent(mapHtml(r));infoWindow.open(roadguardMap,marker)}); markers.push(marker);
  });
}
function showMapNotice(text) { const map=document.getElementById('map'); if(map) { const notice=document.createElement('div'); notice.className='map-toast'; notice.textContent=text; map.appendChild(notice); setTimeout(()=>notice.remove(),3500); } }
document.addEventListener('DOMContentLoaded',()=>{
  const filter=document.getElementById('mapFilter'); if(filter) filter.addEventListener('change',()=>renderMarkers(window.ROADGUARD_REPORTS||[]));
  const locate=document.getElementById('locateMe'); if(locate) locate.addEventListener('click',()=>{if(!navigator.geolocation){showMapNotice('Geolocation is not supported by this browser.');return;}navigator.geolocation.getCurrentPosition(pos=>{const p={lat:pos.coords.latitude,lng:pos.coords.longitude};if(roadguardMap){roadguardMap.setCenter(p);roadguardMap.setZoom(16);new google.maps.Marker({map:roadguardMap,position:p,title:'Your current location'});}else{window.open(`https://www.google.com/maps/@${p.lat},${p.lng},16z`,'_blank');}},()=>showMapNotice('Location unavailable. Allow location permission and try again.'),{enableHighAccuracy:true,timeout:10000});});
  const getLoc=document.getElementById('getLocation'); if(getLoc) getLoc.addEventListener('click',()=>{if(!navigator.geolocation){alert('This browser does not support location.');return;}getLoc.disabled=true;getLoc.textContent='Detecting location…';navigator.geolocation.getCurrentPosition(pos=>{document.getElementById('latitude').value=pos.coords.latitude.toFixed(7);document.getElementById('longitude').value=pos.coords.longitude.toFixed(7);getLoc.disabled=false;getLoc.textContent='✓ Location captured';},err=>{getLoc.disabled=false;getLoc.textContent='◎ Detect my current location';alert(err.code===1?'Please allow location permission in your browser.':'Could not get location. Try outdoors or enter coordinates manually.');},{enableHighAccuracy:true,timeout:12000,maximumAge:30000});});
  const photo=document.getElementById('photo'); if(photo) photo.addEventListener('change',()=>{const preview=document.getElementById('photoPreview');preview.innerHTML='';if(photo.files&&photo.files[0]){const f=photo.files[0];if(f.size>8*1024*1024){alert('Maximum photo size is 8 MB.');photo.value='';return;}const img=document.createElement('img');img.src=URL.createObjectURL(f);img.alt='Selected pothole preview';preview.appendChild(img);const label=document.createElement('small');label.textContent=f.name;preview.appendChild(label);}});
  const search=document.getElementById('searchReports'), status=document.getElementById('statusFilter'), size=document.getElementById('sizeFilter'); function applyFilters(){document.querySelectorAll('#reportsTable tr[data-search]').forEach(row=>{const match=row.dataset.search.includes((search.value||'').toLowerCase())&&(status.value==='All'||row.dataset.status===status.value)&&(size.value==='All'||row.dataset.size===size.value);row.style.display=match?'':'none';});} [search,status,size].forEach(el=>el&&el.addEventListener('input',applyFilters));
  document.querySelectorAll('.recent-item').forEach(btn=>btn.addEventListener('click',()=>{const id=Number(btn.dataset.reportId);const r=(window.ROADGUARD_REPORTS||[]).find(x=>Number(x.id)===id);if(r&&roadguardMap){roadguardMap.setCenter({lat:Number(r.latitude),lng:Number(r.longitude)});roadguardMap.setZoom(17);const m=markers.find(x=>x.getTitle()===r.title);if(m){infoWindow.setContent(mapHtml(r));infoWindow.open(roadguardMap,m);}}else if(r){window.open(`https://www.google.com/maps?q=${r.latitude},${r.longitude}`,'_blank');}}));
});
window.initRoadGuardMap = initRoadGuardMap;
