@echo off
cd /d "%~dp0"
py -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Optional: set GOOGLE_MAPS_API_KEY=YOUR_REAL_KEY before running if you want the interactive Google map.
echo Starting RoadGuard at http://127.0.0.1:5000
python app.py
pause
